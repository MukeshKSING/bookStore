  package com.sulzer.bookstore.domain;
  
  import com.sulzer.bookstore.constants.Category;
  import lombok.AllArgsConstructor;
  import lombok.Builder;
  import lombok.Data;
  import lombok.NoArgsConstructor;
  
  import javax.persistence.Entity;
  import javax.persistence.Id;
  import javax.validation.constraints.Min;
  import javax.validation.constraints.NotNull;
  
  
  @Entity
  @Data
  @Builder
  @AllArgsConstructor
  @NoArgsConstructor
  public class Book {
     
      @Id
      private Long id;
  
     
      @NotNull
      private String title;
  
      private String author;
  
      
      private Category category;
  
      
      @Min(value = 0, message = "Price should be positive value.")
      private float price;
  
    
      @Min(value = 0, message = "Total Count should be positive value.")
      private int totalCount;
  
      
      @Min(value = 0, message = "Total sell should be positive value.")
      private int sold;
  }

