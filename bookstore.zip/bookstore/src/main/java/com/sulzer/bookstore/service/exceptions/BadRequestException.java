  package com.sulzer.bookstore.service.exceptions;
  
  public class BadRequestException extends RuntimeException {
      public BadRequestException(String message) {
          super(message);
      }
  }
